import json
import pathlib
import random
import time

import pandas as pd
from django.shortcuts import render, redirect

# Create your views here.
from django.http import HttpResponse
from django.template import loader

semantic_df = pd.read_csv(pathlib.Path(__file__).parent.parent.joinpath("static", "sampled_semantic", "turkfile.csv"))
semantic_image_a = semantic_df['image_a'].values
semantic_image_b = semantic_df['image_b'].values
# semantic_folder = pathlib.Path(__file__).parent.parent.joinpath("static", "sampled_semantic")
# semantic_order = list(range(len(list(semantic_folder.glob("*.jpg"))) // 2))

realism_df = pd.read_csv(pathlib.Path(__file__).parent.parent.joinpath("static", "sampled_realism", "turkfile.csv"))
realism_df = realism_df.sample(frac=1)
realism_image = realism_df['image'].values

# realism_folder = pathlib.Path(__file__).parent.parent.joinpath("static", "sampled_realism")
# realism_order = list(range(len(list(realism_folder.glob("*.jpg"))) // 2))

# MAX_SEMANTIC_QUESTIONS = len(semantic_image_a)
MAX_SEMANTIC_QUESTIONS = 50
# MAX_REALISM_QUESTIONS = len(realism_image)
MAX_REALISM_QUESTIONS = 50


def index(request):
    if request.session.get('username', None) is None:
        request.session['username'] = request.GET.get("username", None)
        request.session['name'] = request.GET.get("name", None)
        request.session['surname'] = request.GET.get("surname", None)
        request.session['email'] = request.GET.get("email", None)
        request.session['affiliation'] = request.GET.get("affiliation", None)
        return redirect('/polls/login')
    if request.session['username'] is not None:
        if request.session.get('n_semantic', 0) < MAX_SEMANTIC_QUESTIONS:
            return redirect('/polls/semantic')
        else:
            df = pd.DataFrame(request.session.get('semantic_result', {}))
            end_time = df['timestamp'].max()
            result_directory = pathlib.Path(__file__).parent.parent.joinpath("results")
            result_directory.mkdir(parents=True, exist_ok=True)
            csv_file = result_directory.joinpath(f"semantic_{request.session['username']}_{end_time:016f}.csv")
            json_file = result_directory.joinpath(f"semantic_{request.session['username']}_{end_time:016f}.json")
            if not csv_file.exists():
                df.to_csv(csv_file)
            if not json_file.exists():
                json.dump(dict(request.session), open(json_file, "w"))
    if request.session['username'] is not None:
        if request.session.get('n_realism', 0) < MAX_REALISM_QUESTIONS:
            return redirect('/polls/realism')
        else:
            df = pd.DataFrame(request.session.get('realism_result', {}))
            end_time = df['timestamp'].max()
            result_directory = pathlib.Path(__file__).parent.parent.joinpath("results")
            result_directory.mkdir(parents=True, exist_ok=True)
            csv_file = result_directory.joinpath(f"realism_{request.session['username']}_{end_time:016f}.csv")
            json_file = result_directory.joinpath(f"realism_{request.session['username']}_{end_time:016f}.json")
            if not csv_file.exists():
                df.to_csv(csv_file)
            if not json_file.exists():
                json.dump(dict(request.session), open(json_file, "w"))

    return redirect('/polls/final')


def login(request):
    if request.session.get('username', None) is None:
        username = request.GET.get("username", None)
        email = request.GET.get("email", None)
        affiliation = request.GET.get("affiliation", None)
        request.session['username'] = username
        request.session['email'] = email
        request.session['affiliation'] = affiliation
    if request.session.get('username', None) is not None:
        return index(request)
    template = loader.get_template("polls/login.html")
    context = {}
    return HttpResponse(template.render(context, request))


def realism(request):
    if request.session.get('username', None) is None:
        return index(request)
    if request.session.get('realism_df', None) is None:
        request.session['realism_df'] = realism_df.sample(n=MAX_REALISM_QUESTIONS)['image'].values.tolist()
    images = request.session['realism_df']
    if request.method == 'POST':
        params = dict(request.POST)
        params['task'] = ['realism']
        params['timestamp'] = [time.time()]
        print(params)
        current_result = pd.DataFrame(request.session.get('realism_result', {}))
        request.session['realism_result'] = pd.concat([
            current_result,
            pd.DataFrame(params, index=[len(current_result)])]
        ).to_dict()
        request.session['n_realism'] = len(current_result) + 1
    question_index = request.session.get('n_realism', 0)
    if question_index >= MAX_REALISM_QUESTIONS:
        return index(request)
    template = loader.get_template("polls/realism.html")
    context = {
        'image': f'sampled_realism/{images[question_index]}',
        'question_number': request.session.get('n_realism', 0) + 1,
        'total_questions': MAX_REALISM_QUESTIONS,
    }
    return HttpResponse(template.render(context, request))


def semantic(request):
    if request.session.get('username', None) is None:
        return index(request)
    username = request.session.get('username', None)
    if request.session.get('semantic_df', None) is None:
        df = semantic_df.sample(n=MAX_REALISM_QUESTIONS)
        request.session['semantic_df_a'] = df['image_a'].values.tolist()
        request.session['semantic_df_b'] = df['image_b'].values.tolist()
    images_a = request.session['semantic_df_a']
    images_b = request.session['semantic_df_b']
    if request.method == 'POST':
        params = dict(request.POST)
        print(params)
        params['task'] = ['semantic']
        params['timestamp'] = [time.time()]
        current_result = pd.DataFrame(request.session.get('semantic_result', {}))
        request.session['semantic_result'] = pd.concat([
            current_result,
            pd.DataFrame(params, index=[len(current_result)])]
        ).to_dict()
        request.session['n_semantic'] = len(current_result) + 1
    question_index = request.session.get('n_semantic', 0)
    if question_index >= MAX_SEMANTIC_QUESTIONS:
        return index(request)
    template = loader.get_template("polls/semantic.html")
    if random.random() > 0.5:
        context = {
            'left_image': f'sampled_semantic/{images_a[question_index]}',
            'right_image': f'sampled_semantic/{images_b[question_index]}',
            'question_number': request.session.get('n_semantic', 0) + 1,
            'total_questions': MAX_SEMANTIC_QUESTIONS,
        }
    else:
        context = {
            'left_image': f'sampled_semantic/{images_b[question_index]}',
            'right_image': f'sampled_semantic/{images_a[question_index]}',
            'question_number': request.session.get('n_semantic', 0) + 1,
            'total_questions': MAX_SEMANTIC_QUESTIONS,
        }
    return HttpResponse(template.render(context, request))


def reset(request):
    request.session.clear()
    return index(request)


def final(request):
    request.session.clear()
    template = loader.get_template("polls/final.html")
    return HttpResponse(template.render({}, request))
