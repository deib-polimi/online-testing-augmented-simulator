from django.urls import path
from polls import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login, name="login"),
    path("realism", views.realism, name="realism"),
    path("semantic", views.semantic, name="semantic"),
    path("reset", views.reset, name="reset"),
    path("final", views.final, name="final"),
]